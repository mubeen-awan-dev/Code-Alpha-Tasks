// ===== Select Elements =====
const galleryItems = document.querySelectorAll('.gallery-item');
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightboxImg');
const closeBtn = document.getElementById('closeBtn');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const filterBtns = document.querySelectorAll('.filter-btn');

let currentIndex = 0;
let visibleItems = [...galleryItems]; // filtered images array

// ===== Open Lightbox =====
galleryItems.forEach((item, index) => {
  item.addEventListener('click', () => {
    currentIndex = visibleItems.indexOf(item);
    showImage(currentIndex);
    lightbox.classList.add('active');
  });
});

// ===== Show Image in Lightbox =====
function showImage(index) {
  if (visibleItems.length === 0) return;
  if (index < 0) index = visibleItems.length - 1;
  if (index >= visibleItems.length) index = 0;

  currentIndex = index;
  const img = visibleItems[currentIndex].querySelector('img');
  lightboxImg.src = img.src;
  lightboxImg.alt = img.alt;
}

// ===== Next / Prev =====
nextBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  showImage(currentIndex + 1);
});

prevBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  showImage(currentIndex - 1);
});

// ===== Close Lightbox =====
closeBtn.addEventListener('click', () => {
  lightbox.classList.remove('active');
});

lightbox.addEventListener('click', (e) => {
  if (e.target === lightbox) {
    lightbox.classList.remove('active');
  }
});

// ===== Keyboard Navigation =====
document.addEventListener('keydown', (e) => {
  if (!lightbox.classList.contains('active')) return;
  if (e.key === 'ArrowRight') showImage(currentIndex + 1);
  if (e.key === 'ArrowLeft') showImage(currentIndex - 1);
  if (e.key === 'Escape') lightbox.classList.remove('active');
});

// ===== Category Filter (Bonus) =====
filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    // Active class
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const filter = btn.dataset.filter;
    visibleItems = [];

    galleryItems.forEach(item => {
      const category = item.dataset.category;
      if (filter === 'all' || category === filter) {
        item.classList.remove('hide');
        visibleItems.push(item);
      } else {
        item.classList.add('hide');
      }
    });
  });
});

// ===== Touch Swipe Support (Mobile) =====
let touchStartX = 0;
lightbox.addEventListener('touchstart', (e) => {
  touchStartX = e.changedTouches[0].screenX;
});

lightbox.addEventListener('touchend', (e) => {
  const touchEndX = e.changedTouches[0].screenX;
  if (touchEndX < touchStartX - 50) showImage(currentIndex + 1);
  if (touchEndX > touchStartX + 50) showImage(currentIndex - 1);
});
