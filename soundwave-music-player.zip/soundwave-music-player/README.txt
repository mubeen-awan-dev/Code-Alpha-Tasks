SOUNDWAVE MUSIC PLAYER

FILES
- index.html: page structure
- style.css: visual design
- script.js: playlist and audio controls
- audio/: place your own MP3 files here

SETUP
1. Create a folder named audio beside index.html.
2. Add your own audio files and name them song1.mp3, song2.mp3 and song3.mp3.
3. If your files have different names, update the src values in the songs array in script.js.
4. Open index.html in a browser, or use VS Code Live Server.
5. Press Play. Browsers usually require a user click before audio can start.

The included playlist uses placeholder file paths; no copyrighted music is included.
