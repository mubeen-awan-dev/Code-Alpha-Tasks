const songs = [
  // Replace these sample paths with your own MP3 files in the audio folder.
  { title: "Midnight Drive", artist: "Nova Lane", src: "audio/song1.mp3", color: "linear-gradient(145deg,#41376e,#b17acb 48%,#e2a9a2)" },
  { title: "Golden Hour", artist: "The Paper Skies", src: "audio/song2.mp3", color: "linear-gradient(145deg,#754b4b,#d6a36d 55%,#f0c99b)" },
  { title: "Ocean Lights", artist: "Mira Sol", src: "audio/song3.mp3", color: "linear-gradient(145deg,#245b60,#63a89b 55%,#b3d6bd)" }
];

const audio = document.getElementById("audio");
const playButton = document.getElementById("playButton");
const progress = document.getElementById("progress");
const volume = document.getElementById("volume");
const playlist = document.getElementById("playlist");
let currentIndex = 0;
let isShuffle = false;
let repeatOne = false;

function formatTime(seconds) {
  if (!Number.isFinite(seconds)) return "0:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60).toString().padStart(2, "0");
  return `${mins}:${secs}`;
}

function renderPlaylist() {
  playlist.innerHTML = "";
  songs.forEach((song, index) => {
    const item = document.createElement("button");
    item.className = `track ${index === currentIndex ? "active" : ""}`;
    item.type = "button";
    item.innerHTML = `
      <span class="track-number">${index === currentIndex && !audio.paused ? "♫" : String(index + 1).padStart(2, "0")}</span>
      <span class="track-thumb">♫</span>
      <span class="track-details"><strong></strong><small></small></span>
      <span class="track-duration" id="track-duration-${index}">--:--</span>`;
    item.querySelector("strong").textContent = song.title;
    item.querySelector("small").textContent = song.artist;
    item.addEventListener("click", () => loadSong(index, true));
    playlist.appendChild(item);
  });
  document.getElementById("trackCount").textContent = `${String(songs.length).padStart(2, "0")} TRACKS`;
}

function loadSong(index, autoplay = false) {
  currentIndex = (index + songs.length) % songs.length;
  const song = songs[currentIndex];
  audio.src = song.src;
  document.getElementById("songTitle").textContent = song.title;
  document.getElementById("artistName").textContent = song.artist;
  document.getElementById("coverArt").style.background = song.color;
  document.getElementById("currentTime").textContent = "0:00";
  document.getElementById("duration").textContent = "0:00";
  progress.value = 0;
  renderPlaylist();
  if (autoplay) playSong();
  else updatePlayButton();
}

async function playSong() {
  try {
    await audio.play();
    updatePlayButton();
    renderPlaylist();
  } catch (error) {
    updatePlayButton();
    console.warn("Audio could not play. Check that the MP3 file exists:", error);
  }
}

function pauseSong() {
  audio.pause();
  updatePlayButton();
  renderPlaylist();
}

function updatePlayButton() {
  const playing = !audio.paused;
  playButton.textContent = playing ? "Ⅱ" : "▶";
  playButton.setAttribute("aria-label", playing ? "Pause" : "Play");
}

function nextSong() {
  if (isShuffle && songs.length > 1) {
    let next;
    do { next = Math.floor(Math.random() * songs.length); } while (next === currentIndex);
    loadSong(next, true);
  } else {
    loadSong(currentIndex + 1, true);
  }
}

function previousSong() {
  if (audio.currentTime > 3) {
    audio.currentTime = 0;
  } else {
    loadSong(currentIndex - 1, true);
  }
}

playButton.addEventListener("click", () => audio.paused ? playSong() : pauseSong());
document.getElementById("nextButton").addEventListener("click", nextSong);
document.getElementById("previousButton").addEventListener("click", previousSong);

audio.addEventListener("loadedmetadata", () => {
  document.getElementById("duration").textContent = formatTime(audio.duration);
  const durationLabel = document.getElementById(`track-duration-${currentIndex}`);
  if (durationLabel) durationLabel.textContent = formatTime(audio.duration);
});

audio.addEventListener("timeupdate", () => {
  if (!Number.isFinite(audio.duration) || audio.duration === 0) return;
  progress.value = (audio.currentTime / audio.duration) * 100;
  document.getElementById("currentTime").textContent = formatTime(audio.currentTime);
});

progress.addEventListener("input", () => {
  if (Number.isFinite(audio.duration)) {
    audio.currentTime = (progress.value / 100) * audio.duration;
  }
});

volume.addEventListener("input", () => {
  audio.volume = Number(volume.value);
  document.getElementById("volumeValue").textContent = `${Math.round(audio.volume * 100)}%`;
});

document.getElementById("shuffleButton").addEventListener("click", event => {
  isShuffle = !isShuffle;
  event.currentTarget.classList.toggle("active", isShuffle);
});

document.getElementById("repeatButton").addEventListener("click", event => {
  repeatOne = !repeatOne;
  audio.loop = repeatOne;
  event.currentTarget.classList.toggle("active", repeatOne);
});

audio.addEventListener("ended", () => {
  if (!repeatOne) nextSong();
});

document.getElementById("likeButton").addEventListener("click", event => {
  const liked = event.currentTarget.classList.toggle("liked");
  event.currentTarget.textContent = liked ? "♥" : "♡";
});

audio.volume = Number(volume.value);
renderPlaylist();
loadSong(0);

// Autoplay is intentionally not forced on page load because browsers
// generally block audio until the visitor interacts with the page.
