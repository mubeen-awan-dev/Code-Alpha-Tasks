MUBEEN UR REHMAN - PERSONAL PORTFOLIO

FILES
- index.html: portfolio content and sections
- style.css: responsive design, colours, hover effects and animations
- script.js: mobile navigation, current year and scroll reveal animation

HOW TO RUN
1. Extract the ZIP file.
2. Open the extracted folder in Visual Studio Code.
3. Open index.html in your browser, or use the Live Server extension.
4. Replace placeholder LinkedIn/GitHub links and project links with Mubeen's real links.
5. Review the education, internship, skills and project information to make sure it is accurate before publishing.
6. Email is intentionally not displayed.

DEPLOY ON GITHUB PAGES
1. Create/sign in to GitHub and create a new public repository.
2. Upload index.html, style.css, script.js and README.txt to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, select Deploy from a branch.
5. Select the main branch and / (root), then Save.
6. Wait for GitHub to publish the site. The Pages URL will appear in Settings > Pages.

IMPORTANT
The content structure follows the portfolio details provided for the reference portfolio.
Please verify that Mubeen has the same education, experience, skills and projects before using it as his public CV.
